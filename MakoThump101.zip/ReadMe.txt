MAKO THUMP VST3
Author: Rosbone Mako
Date: 5/6/2024

This VST3 is sample code to show how to create a Thump Guitar effect.

The code creates a 150Hz low pass filter and applies it to a guitar
signal to emulate speaker cabinet thump and compression. It can be
used for any signal such as bass, keyboards, drums, etc.

The included code is for a JUCE Basic VST project. The project uses a PNG
image as a background. This can be removed, comment out any img code in editor.
It was built on Windows and tested in Reaper (DAW).

The thump effect is pretty cool, feel free to add it to anything you like. Or
modify this cade to make your own crazy effects.

ISSUES:
- VST was built on MS C++ 2022 and may require MS Runtime files.
- Last known state does not work in DAW. Stored presets work. 